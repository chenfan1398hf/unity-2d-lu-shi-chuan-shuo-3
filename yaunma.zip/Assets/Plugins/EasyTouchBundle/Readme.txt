**********************************************
				EASY TOUCH 5
				
Copyright © 2016 The Hedgehog Team
http://www.thehedgehogteam.com/Forum/

		the.hedgehog.team@gmail.com

**********************************************

Thank you for your purchase!

If you have any questions, suggestions, please
use the Hedgehog Team Community forum,  here: http://www.thehedgehogteam.com/Forum/

Or send us an email at : the.hedgehog.team@gmail.com

If you like EasyTouch, don't forget a write a review on the asset store :-)


Look at Youtube channel for new EasyTouch 5 features : https://www.youtube.com/playlist?list=PL_xsQKiLfGUYpZt7uDepdadHo7GBGbozH

EasyTouch Bundle 5.0.17
***********************
* PlayMaker Add-on => 1.0.3
* EasyTouch => 5.0.12
* EasyTouch Controls => 2.0.9

EasyTouch Bundle 5.0.16
***********************
* PlayMaker Add-on => 1.0.3
* EasyTouch => 5.0.12
* EasyTouch Controls => 2.0.8

EasyTouch Bundle 5.0.15
***********************
* PlayMaker Add-on => 1.0.3
* EasyTouch => 5.0.11
* EasyTouch Controls => 2.0.8

EasyTouch Bundle 5.0.14
***********************
* PlayMaker Add-on => 1.0.2
* EasyTouch => 5.0.10
* EasyTouch Controls => 2.0.7

EasyTouch Bundle 5.0.13
***********************
* PlayMaker Add-on => 1.0.2
* EasyTouch => 5.0.9
* EasyTouch Controls => 2.0.7

EasyTouch Bundle 5.0.12
***********************
* PlayMaker Add-on => 1.0.2
* EasyTouch => 5.0.8
* EasyTouch Controls => 2.0.7

EasyTouch Bundle 5.0.11
***********************
* PlayMaker Add-on => 1.0.2
* EasyTouch => 5.0.7
* EasyTouch Controls => 2.0.7

EasyTouch Bundle 5.0.10
***********************
* PlayMaker Add-on => 1.0.2
* EasyTouch => 5.0.6
* EasyTouch Controls => 2.0.7


EasyTouch Bundle 5.0.9
***********************
* PlayMaker Add-on => 1.0.2
* EasyTouch => 5.0.5
* EasyTouch Controls => 2.0.7

EasyTouch Bundle 5.0.8
***********************
* PlayMaker Add-on => 1.0.1
* EasyTouch => 5.0.4
* EasyTouch Controls => 2.0.7

EasyTouch Bundle 5.0.7
***********************
* PlayMaker Add-on => 1.0.1
* EasyTouch => 5.0.4
* EasyTouch Controls => 2.0.6


EasyTouch Bundle 5.0.6
***********************
* EasyTouch => 5.0.4
* EasyTouch Controls => 2.0.6

EasyTouch Bundle 5.0.5
***********************
* EasyTouch => 5.0.3
* EasyTouch Controls => 2.0.6

EasyTouch Bundle 5.0.4
***********************
* EasyTouch => 5.0.2
* EasyTouch Controls => 2.0.5

EasyTouch Bundle 5.0.3
***********************
EasyTouch => 5.0.2
EasyTouch Controls => 2.0.4

EasyTouch Bundle 5.0.2
***********************
EasyTouch => 5.0.2
EasyTouch Controls => 2.0.3

EasyTouch Bundle 5.0.1
***********************
EasyTouch => 5.0.1
EasyTouch Controls => 2.0.3


EasyTouch Bundle 5.0.0
***********************
EasyTouch => 5.0.0
EasyTouch Controls => 2.0.3

